# QAM2 — QAM2 TASK 1: JAVA APPLICATION DEVELOPMENT

### Purpose of application
Brief description of your project...

### Author Information
- Name: Lucas Gale
- Contact: lgale5@wgu.edu
- application version: 1.0
- date: 01/20/2024


### IDE and Java module version
- IntelliJ IDEA 2022.3.2 (Community Edition)
- java version "17.0.6" 2023-01-17 LTS
- Java(TM) SE Runtime Environment (build 17.0.6+9-LTS-190)
- Java HotSpot(TM) 64-Bit Server VM (build 17.0.6+9-LTS-190, mixed mode, sharing)
- JavaFX-sdk-20.0.2
- mysql-connector-j-8.2.0

### How to Run the Program
Once you start the program, you will be presented with a login screen. 
You will need to enter a valid username and password that matches information in a database.
Once you are logged in, you will be presented with a screen that shows your appointments.

### Additional Report
For the custom report, I chose to display the first-level division (state/province) of each customer 
and display the total number of customers in that division. The reportScreen controller gets all customers, puts them in a hash map,
iterates through customers and count occurrences of each state, creates report objects for all divisions with occurrences, and displays them in a tableview. 

