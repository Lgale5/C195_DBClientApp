package model;

/**
 * Class to create Users objects.
 */
public class Users {
    public int userID;
    public static String userName;
    public String userPassword;

    /**
     * Constructor for Users objects.
     */
    public Users() {
        this.userID = userID;
        this.userName = userName;
        this.userPassword = userPassword;
    }

    /**
     *
     * @return userName
     */
    public String getUserName() {

        return userName;
    }

    /**
     *
     * @return userID
     */
    public int getUserID() {

        return userID;
    }

    /**
     *
     * @return userPassword
     */
    public String getUserPassword() {

        return userPassword;
    }
}
