package model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Class for Appointments.
 * This class is used to create Appointments objects.
 */
public class Appointments {
    private int appointmentID;
    private String appointmentTitle;
    private String appointmentDescription;
    private String appointmentLocation;
    private String appointmentType;
    private LocalDateTime appointmentStart;
    private LocalDateTime appointmentEnd;

    public int customerID;
    public int userID;
    public int contactID;

    /**
     * Constructor for Appointments class.
     * @param appointmentID
     * @param appointmentTitle
     * @param appointmentDescription
     * @param appointmentLocation
     * @param appointmentType
     * @param appointmentStart
     * @param appointmentEnd
     * @param customerID
     * @param userID
     * @param contactID
     */
    public Appointments(int appointmentID, String appointmentTitle, String appointmentDescription,
                        String appointmentLocation, String appointmentType, LocalDateTime appointmentStart, LocalDateTime appointmentEnd, int customerID,
                        int userID, int contactID) {
        this.appointmentID = appointmentID;
        this.appointmentTitle = appointmentTitle;
        this.appointmentDescription = appointmentDescription;
        this.appointmentLocation = appointmentLocation;
        this.appointmentType = appointmentType;
        this.appointmentStart = appointmentStart;
        this.appointmentEnd = appointmentEnd;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
    }

    /**
     *
     * @return appointmentID
     */
    public int getAppointmentID() {

        return appointmentID;
    }

    /**
     *
     * @return appointmentTitle
     */
    public String getAppointmentTitle() {

        return appointmentTitle;
    }

    /**
     *
     * @return appointmentDescription
     */
    public String getAppointmentDescription() {

        return appointmentDescription;
    }

    /**
     *
     * @return appointmentLocation
     */
    public String getAppointmentLocation() {

        return appointmentLocation;
    }

    /**
     *
     * @return appointmentType
     */
    public String getAppointmentType() {

        return appointmentType;
    }

    /**
     * Gets the start time of the appointment.
     *
     * @return The start time in LocalDateTime.
     */
    public LocalDateTime getAppointmentStart() {

        return appointmentStart;
    }

    /**
     * Gets the end time of the appointment.
     *
     * @return The end time in LocalDateTime.
     */
    public LocalDateTime getAppointmentEnd() {

        return appointmentEnd;
    }

    /**
     *
     * @return customerID
     */
    public int getCustomerID () {

        return customerID;
    }

    /**
     *
     * @return The customer ID.
     */
    public int getUserID() {

        return userID;
    }

    /**
     *
     * @return contactID
     */
    public int getContactID() {

        return contactID;
    }

    /**
     * Gets the start time of the appointment.
     *
     * @return The start time in LocalDateTime.
     */
    public LocalDateTime getStart() {

        return appointmentStart;
    }

    /**
     * Gets the end time of the appointment.
     *
     * @return The end time in LocalDateTime.
     */
    public LocalDateTime getEnd() {

        return appointmentEnd;
    }

    /**
     * Gets the start time of the appointment formatted in the local time zone.
     *
     * @return The start time in LocalDateTime.
     */
    public StringProperty appointmentStartLocalFormattedProperty() {
        ZonedDateTime startLocal = getAppointmentStart().atZone(ZoneId.of("UTC")).withZoneSameInstant(ZoneId.systemDefault());
        return new SimpleStringProperty(startLocal.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    }

    /**
     * Gets the end time of the appointment formatted in the local time zone.
     *
     * @return The end time in LocalDateTime.
     */
    public StringProperty appointmentEndLocalFormattedProperty() {
        ZonedDateTime endLocal = getAppointmentEnd().atZone(ZoneId.of("UTC")).withZoneSameInstant(ZoneId.systemDefault());
        return new SimpleStringProperty(endLocal.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    }

}
