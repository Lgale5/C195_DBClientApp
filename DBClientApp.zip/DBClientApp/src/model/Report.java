package model;

/**
 * Class to create Report objects representing various data for reporting purposes.
 */
public class Report {

    public String appointmentMonth;
    public String appointmentType;
    public int appointmentMonthTotal;
    public int appointmentTypeTotal;
    public String customerState;
    public int customerStateTotal;

    /**
     *
     * @return appointmentType
     */
    public String getAppointmentType() {

        return appointmentType;
    }

    /**
     *
     * @return appointmentMonth
     */
    public String getAppointmentMonth() {

        return appointmentMonth;
    }

    /**
     *
     * @return appointmentTypeTotal
     */
    public int getAppointmentTypeTotal() {

        return appointmentTypeTotal;
    }

    /**
     *
     * @return appointmentMonthTotal
     */
    public int getAppointmentMonthTotal() {

        return appointmentMonthTotal;
    }

    /**
     *
     * @return customerState
     */
    public String getCustomerState() {

        return customerState;
    }

    /**
     *
     * @return customerStateTotal
     */
    public int getCustomerStateTotal() {

        return customerStateTotal;
    }

}
