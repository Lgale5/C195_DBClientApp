package model;

/**
 * Class to create Country objects.
 */
public class Country {
    private int countryID;
    private String countryName;

    /**
     * Constructor for Country objects.
     * @param countryID
     * @param countryName
     */
    public Country(int countryID, String countryName) {
        this.countryID = countryID;
        this.countryName = countryName;
    }

    /**
     *
     * @return countryID
     */
        public int getCountryID() {

            return countryID;
        }

    /**
     *
     * @return countryName
     */
    public String getCountryName() {

        return countryName;
    }

}
