package model;

/**
 * Class to create FirstLevelDivisions objects.
 */
public class FirstLevelDivisions {
    private int divisionID;
    private String division;
    public int countryID;

    /**
     * Constructor for FirstLevelDivisions objects.
     * @param divisionID
     * @param division
     * @param countryID
     */
    public FirstLevelDivisions(int divisionID, String division, int countryID) {
        this.divisionID = divisionID;
        this.division = division;
        this.countryID = countryID;
    }

    /**
     *
     * @return divisionID
     */
    public int getDivisionID() {

        return divisionID;
    }

    /**
     *
     * @return division
     */
    public String getDivision() {

        return division;
    }

    /**
     *
     * @return countryID
     */
    public int getCountryID() {

        return countryID;
    }

}