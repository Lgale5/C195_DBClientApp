package helper;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility class for handling time conversions in the Appointment Application.
 * Provides methods to convert between UTC (Coordinated Universal Time) and local time.
 */
public class timeUtility {

    /**
     * Converts a given date and time string to UTC (Coordinated Universal Time).
     *
     * @param dateTime The date and time string to be converted.
     * @return A string representing the converted date and time in UTC.
     */
    public static String convertToUTC(String dateTime) {
        Timestamp currentTimeStamp = Timestamp.valueOf(String.valueOf(dateTime));
        LocalDateTime LocalDT = currentTimeStamp.toLocalDateTime();
        ZonedDateTime zoneDT = LocalDT.atZone(ZoneId.of(ZoneId.systemDefault().toString()));
        ZonedDateTime utcDT = zoneDT.withZoneSameInstant(ZoneId.of("UTC"));
        LocalDateTime localOUT = utcDT.toLocalDateTime();
        String utcOUT = localOUT.format(DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss"));
        return utcOUT;
    }

    /**
     * Converts a UTC (Coordinated Universal Time) date and time string to local time.
     *
     * @param utcDateTime The UTC date and time string to be converted.
     * @return A string representing the converted date and time in the local time zone.
     */
    public static String convertUTCToLocal(String utcDateTime) {
        LocalDateTime utcLocalDT = LocalDateTime.parse(utcDateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        ZonedDateTime utcZonedDateTime = utcLocalDT.atZone(ZoneId.of("UTC"));
        ZonedDateTime localZonedDateTime = utcZonedDateTime.withZoneSameInstant(ZoneId.systemDefault());
        return localZonedDateTime.toLocalDateTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

}
