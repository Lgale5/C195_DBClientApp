package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Contacts;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object (DAO) class for managing contacts in the Appointment Application.
 * Provides methods for retrieving contacts from the database.
 */
public class contactsAccess {

    /**
     * Retrieves all contacts from the database.
     *
     * @return An ObservableList of Contacts containing all contacts in the database.
     * @throws SQLException If an SQL exception occurs during the retrieval of contacts.
     */
    public static ObservableList<Contacts> getAllContacts() throws SQLException {
        ObservableList<Contacts> contactsObservableList = FXCollections.observableArrayList();
        String sql = "SELECT * from contacts";
        PreparedStatement ps = JDBC.openConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int contactID = rs.getInt("Contact_ID");
            String contactName = rs.getString("Contact_Name");
            String contactEmail = rs.getString("Email");
            Contacts contact = new Contacts(contactID, contactName, contactEmail);
            contactsObservableList.add(contact);
        }
        return contactsObservableList;
    }

    /**
     * Finds the contact ID based on the contact name.
     *
     * @param contactID The contact name to search for.
     * @return The contact ID corresponding to the given contact name.
     * @throws SQLException If an SQL exception occurs during the retrieval of the contact ID.
     */
    public static String findContactID(String contactID) throws SQLException {
        PreparedStatement ps = JDBC.openConnection().prepareStatement("SELECT * FROM contacts WHERE Contact_Name = ?");
        ps.setString(1, contactID);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            contactID = rs.getString("Contact_ID");
        }
        return contactID;
    }
}
