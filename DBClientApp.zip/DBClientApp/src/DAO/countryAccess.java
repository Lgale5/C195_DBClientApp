package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Country;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object (DAO) class for managing countries in the Appointment Application.
 * Provides methods for retrieving countries from the database.
 */
public class countryAccess extends Country {

    /**
     * Constructor for the countryAccess class.
     *
     * @param countryID   The ID of the country.
     * @param countryName The name of the country.
     */
    public countryAccess(int countryID, String countryName) {
        super(countryID, countryName);
    }

    /**
     * Retrieves all countries from the database.
     *
     * @return An ObservableList of Countries containing all countries in the database.
     * @throws SQLException If an SQL exception occurs during the retrieval of countries.
     */
    public static ObservableList<countryAccess> getAllCountries() throws SQLException {
        ObservableList<countryAccess> countriesOL = FXCollections.observableArrayList();
        String sql = "SELECT Country_ID, Country from countries";
        PreparedStatement ps = JDBC.openConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int countryID = rs.getInt("Country_ID");
            String countryName = rs.getString("Country");
            countryAccess country = new countryAccess(countryID, countryName);
            countriesOL.add(country);
        }
        return countriesOL;
    }

    /**
     * Retrieves the names of all countries from the database.
     *
     * @return An ObservableList of Strings containing the names of all countries in the database.
     * @throws SQLException If an SQL exception occurs during the retrieval of country names.
     */
    public static ObservableList<String> getCountries() throws SQLException {
        ObservableList<String> countryNames = FXCollections.observableArrayList();
        String sql = "SELECT Country from countries";
        PreparedStatement ps = JDBC.openConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            String countryName = rs.getString("Country");
            countryNames.add(countryName);
        }
        return countryNames;
    }

}
