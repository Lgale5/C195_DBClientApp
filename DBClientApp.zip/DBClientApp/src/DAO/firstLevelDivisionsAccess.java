package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Country;
import model.FirstLevelDivisions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object (DAO) class for managing first-level divisions in the Appointment Application.
 * Provides methods for retrieving information about first-level divisions and their associated countries from the database.
 */
public class firstLevelDivisionsAccess extends FirstLevelDivisions {

    /**
     * Constructor for the firstLevelDivisionsAccess class.
     *
     * @param divisionID The ID of the first-level division.
     * @param division   The name of the first-level division.
     * @param countryID  The ID of the associated country.
     */
    public firstLevelDivisionsAccess(int divisionID, String division, int countryID) {
        super(divisionID, division, countryID);
    }

    /**
     * Retrieves all first-level divisions from the database.
     *
     * @return An ObservableList of FirstLevelDivisions containing all first-level divisions in the database.
     * @throws SQLException If an SQL exception occurs during the retrieval of first-level divisions.
     */
    public static ObservableList<firstLevelDivisionsAccess> getAllFirstLevelDivisions() throws SQLException {
        ObservableList<firstLevelDivisionsAccess> firstLevelDivisionsOL = FXCollections.observableArrayList();
        String sql = "SELECT * from first_level_divisions";
        PreparedStatement ps = JDBC.openConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int divisionID = rs.getInt("Division_ID");
            String divisionName = rs.getString("Division");
            int country_ID = rs.getInt("COUNTRY_ID");
            firstLevelDivisionsAccess firstLevelDivisions = new firstLevelDivisionsAccess(divisionID, divisionName, country_ID);
            firstLevelDivisionsOL.add(firstLevelDivisions);
        }
        return firstLevelDivisionsOL;
    }

    /**
     * Retrieves a list of states (first-level divisions) for a given country.
     *
     * @param countryName The name of the country for which states are to be retrieved.
     * @return An ObservableList of strings containing the names of states for the specified country.
     * @throws SQLException If an SQL exception occurs during the retrieval of states.
     */
    public static ObservableList<String> getStatesByCountry(String countryName) throws SQLException {
        ObservableList<String> statesOL = FXCollections.observableArrayList();

        String sql = "SELECT Division FROM first_level_divisions WHERE Country_ID IN (SELECT Country_ID FROM countries WHERE Country = ?)";
        try (PreparedStatement ps = JDBC.openConnection().prepareStatement(sql)) {
            ps.setString(1, countryName);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String divisionName = rs.getString("Division");
                    statesOL.add(divisionName);
                }
            }
        }
        return statesOL;
    }

    /**
     * Retrieves the country associated with a given first-level division ID.
     *
     * @param divisionID The ID of the first-level division for which the country is to be retrieved.
     * @return A Country object representing the associated country.
     * @throws SQLException If an SQL exception occurs during the retrieval of the associated country.
     */
    public static Country getCountryByDivisionID(int divisionID) throws SQLException {
        String sql = "SELECT countries.Country_ID, countries.Country " +
                "FROM first_level_divisions " +
                "JOIN countries ON first_level_divisions.COUNTRY_ID = countries.Country_ID " +
                "WHERE first_level_divisions.Division_ID = ?";
        try (PreparedStatement ps = JDBC.openConnection().prepareStatement(sql)) {
            ps.setInt(1, divisionID);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int countryID = rs.getInt("Country_ID");
                    String countryName = rs.getString("Country");
                    return

                            new Country(countryID, countryName);
                } else {
                    return null; // Handle the case where no country is found
                }
            }
        }
    }
}
