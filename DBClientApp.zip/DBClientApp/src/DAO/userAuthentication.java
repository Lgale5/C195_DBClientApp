package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Users;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object (DAO) class for user authentication in the Appointment Application.
 * Provides methods for authenticating users, retrieving user information, and managing user sessions.
 */
public class userAuthentication extends Users {

    /**
     * Constructor for the userAuthentication class.
     *
     * @param userID       The ID of the user.
     * @param userName     The name of the user.
     * @param userPassword The password of the user.
     */
    public userAuthentication(int userID, String userName, String userPassword) {
        super();
    }

    /**
     * Authenticates a user based on the provided username and password.
     *
     * @param username The username to authenticate.
     * @param password The password to authenticate.
     * @return The ID of the authenticated user, or -1 if the user is not authenticated.
     */
    public static int authenticateUser(String username, String password) {
        try {
            String sqlQuery = "SELECT User_ID FROM users WHERE User_Name = ? AND Password = ?";
            PreparedStatement ps = JDBC.openConnection().prepareStatement(sqlQuery);
            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("User_ID");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Retrieves a list of all users from the database.
     *
     * @return An ObservableList of userAuthentication containing all users in the database.
     * @throws SQLException If an SQL exception occurs during the retrieval of users.
     */
    public static ObservableList<userAuthentication> getAllUsers() throws SQLException {
        ObservableList<userAuthentication> usersObservableList = FXCollections.observableArrayList();
        String sql = "SELECT * from users";
        PreparedStatement ps = JDBC.openConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int userID = rs.getInt("User_ID");
            String userName = rs.getString("User_Name");
            String userPassword = rs.getString("Password");
            userAuthentication user = new userAuthentication(userID, userName, userPassword);
            usersObservableList.add(user);
        }
        return usersObservableList;
    }

    private static int currentUserId = -1; // Assume no user is logged in initially

    /**
     * Gets the ID of the currently logged-in user.
     *
     * @return The ID of the currently logged-in user, or -1 if no user is logged in.
     */
    public static int getCurrentUserId() {
        return currentUserId;
    }

    /**
     * Gets the currently logged-in user.
     *
     * @return The currently logged-in user, or null if no user is logged in.
     */
    public static Users getCurrentUser() {
        if (currentUserId != -1) {
            try {
                ObservableList<userAuthentication> users = getAllUsers();
                for (userAuthentication user : users) {
                    if (user.getUserID() == currentUserId) {
                        return user;
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null; // No user logged in
    }

    /**
     * Sets the ID of the currently logged-in user.
     *
     * @param userId The ID of the user to set as the currently logged-in user.
     */
    public static void setCurrentUserId(int userId) {
        currentUserId = userId;
    }

    /**
     * Logs the current user out of the application.
     */
    public static void logout() {
        currentUserId = -1; // Reset current user on logout
    }
}
