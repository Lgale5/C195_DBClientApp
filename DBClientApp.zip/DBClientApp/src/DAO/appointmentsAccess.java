package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Appointments;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;

/**
 * Data Access Object (DAO) class for managing appointments in the Appointment Application.
 * Provides methods for retrieving, creating, and deleting appointment records in the database.
 */
public class appointmentsAccess {

    /**
     * Retrieves all appointments from the database.
     *
     * @return An ObservableList of Appointments containing all appointments in the database.
     * @throws SQLException If an SQL exception occurs during the retrieval of appointments.
     */
    public static ObservableList<Appointments> getAllAppointments() throws SQLException {
        ObservableList<Appointments> appointmentsOL = FXCollections.observableArrayList();
        String sql = "SELECT * from appointments";
        PreparedStatement ps = JDBC.openConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int appointmentID = rs.getInt("Appointment_ID");
            String appointmentTitle = rs.getString("Title");
            String appointmentDescription = rs.getString("Description");
            String appointmentLocation = rs.getString("Location");
            String appointmentType = rs.getString("Type");
            LocalDateTime appointmentStart = rs.getObject("Start", ZonedDateTime.class).toLocalDateTime();
            LocalDateTime appointmentEnd = rs.getObject("End", ZonedDateTime.class).toLocalDateTime();
            int customerID = rs.getInt("Customer_ID");
            int userID = rs.getInt("User_ID");
            int contactID = rs.getInt("Contact_ID");
            Appointments appointment = new Appointments(appointmentID, appointmentTitle, appointmentDescription, appointmentLocation, appointmentType, appointmentStart, appointmentEnd, customerID, userID, contactID);
            appointmentsOL.add(appointment);
        }

        return appointmentsOL;
    }

    /**
     * Retrieves the next available appointment ID.
     *
     * @return The next available appointment ID.
     * @throws SQLException If an SQL exception occurs during the retrieval of the next appointment ID.
     */
    public static int getNextAppointmentID() throws SQLException {
        String query = "SELECT MAX(Appointment_ID) + 1 AS NextAppointmentID FROM client_schedule.appointments";
        try (Connection connection = JDBC.openConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("NextAppointmentID");
            }
            return 1; // If no records, start from 1
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Deletes appointments associated with a specific customer.
     *
     * @param customerId The ID of the customer whose appointments should be deleted.
     * @throws SQLException If an SQL exception occurs during the deletion of appointments.
     */
    public static void deleteAppointmentsByCustomer(int customerId) throws SQLException {
        String sql = "DELETE FROM appointments WHERE Customer_ID = ?";
        try (Connection connection = JDBC.openConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, customerId);
            preparedStatement.executeUpdate();
        }
    }

    /**
     * Deletes a specific appointment based on its ID.
     *
     * @param appointmentID The ID of the appointment to be deleted.
     * @throws SQLException If an SQL exception occurs during the deletion of the appointment.
     */
    public static void deleteAppointment(int appointmentID) throws SQLException {
        String sql = "DELETE FROM appointments WHERE Appointment_ID = ?";
        try (Connection connection = JDBC.openConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, appointmentID);
            preparedStatement.executeUpdate();
        }
    }

}
