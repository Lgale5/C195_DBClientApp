package DAO;

import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Customers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Data Access Object (DAO) class for managing customers in the Appointment Application.
 * Provides methods for retrieving, creating, and deleting customer records in the database.
 */
public class customersAccess {

    /**
     * Retrieves all customers from the database, including additional information such as address, postal code, and phone number.
     *
     * @return An ObservableList of Customers containing all customers in the database.
     * @throws SQLException If an SQL exception occurs during the retrieval of customers.
     */
    public static ObservableList<Customers> getAllCustomers() throws SQLException {
        try {
            ObservableList<Customers> customersOL = FXCollections.observableArrayList();
            String query = "SELECT customers.Customer_ID, customers.Customer_Name, customers.Address, customers.Postal_Code, customers.Phone, first_level_divisions.Division_ID, first_level_divisions.Division " +
                    "FROM client_schedule.customers " +
                    "inner join client_schedule.first_level_divisions " +
                    "ON customers.Division_ID = client_schedule.first_level_divisions.Division_ID";

            PreparedStatement ps = JDBC.openConnection().prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int customerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String customerPostalCode = rs.getString("Postal_Code");
                String customerPhone = rs.getString("Phone");
                int divisionID = rs.getInt("Division_ID");
                String division = rs.getString("Division");
                Customers customer = new Customers(customerID, customerName, customerAddress, customerPostalCode, customerPhone, divisionID, division);
                customersOL.add(customer);
            }
            return customersOL;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Retrieves the next available customer ID.
     *
     * @return The next available customer ID.
     * @throws SQLException If an SQL exception occurs during the retrieval of the next customer ID.
     */
    public static int getNextCustomerID() throws SQLException {
        try {
            String query = "SELECT MAX(Customer_ID) + 1 AS NextCustomerID FROM client_schedule.customers";
            PreparedStatement ps = JDBC.openConnection().prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("NextCustomerID");
            }
            return 1; // If no records, start from 1
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Deletes a customer from the database based on the provided customer ID.
     *
     * @param customerId The ID of the customer to be deleted.
     * @throws SQLException If an SQL exception occurs during the deletion of the customer.
     */
    public static void deleteCustomer(int customerId) throws SQLException {
        String sql = "DELETE FROM customers WHERE Customer_ID = ?";
        try (Connection connection = JDBC.openConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, customerId);
            preparedStatement.executeUpdate();
        }
    }

}
