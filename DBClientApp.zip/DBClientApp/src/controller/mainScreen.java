package controller;

import DAO.appointmentsAccess;
import DAO.customersAccess;
import DAO.firstLevelDivisionsAccess;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;
import model.Customers;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Controller class for the main screen of the Appointment Application.
 * Handles actions and initializes the main screen components.
 */
public class mainScreen {

    @FXML
    private RadioButton currentWeekRadio;
    @FXML
    private RadioButton currentMonthRadio;
    @FXML
    private RadioButton allAppointmentsRadio;
    @FXML
    private TableView<Appointments> appointmentsTable;
    @FXML
    private TableColumn<?, ?> appointmentID;
    @FXML
    private TableColumn<?, ?> appointmentTitle;
    @FXML
    private TableColumn<?, ?> appointmentDescription;
    @FXML
    private TableColumn<?, ?> appointmentLocation;
    @FXML
    private TableColumn<?, ?> appointmentContact;
    @FXML
    private TableColumn<?, ?> appointmentType;
    @FXML
    private TableColumn<?, ?> appointmentStart;
    @FXML
    private TableColumn<?, ?> appointmentEnd;
    @FXML
    private TableColumn<?, ?> appointmentCustomerID;
    @FXML
    private TableColumn<?, ?> appointmentUserID;
    @FXML
    private Button addAppointmentButton;
    @FXML
    private Button updateAppointmentButton;
    @FXML
    private Button deleteAppointmentButton;
    @FXML
    private TableView<Customers> CustomersTable;
    @FXML
    private TableColumn<?, ?> customerID;
    @FXML
    private TableColumn<?, ?> customerName;
    @FXML
    private TableColumn<?, ?> customerAddress;
    @FXML
    private TableColumn<?, ?> customerPostalCode;
    @FXML
    private TableColumn<?, ?> customerPhone;
    @FXML
    private TableColumn<Customers, String> customerDivision;
    @FXML
    private Button addCustomerButton;
    @FXML
    private Button updateCustomerButton;
    @FXML
    private Button deleteCustomerButton;
    @FXML
    private Button reportsButton;
    @FXML
    private Button exitButton;
    @FXML
    private TextField customerIDField;
    @FXML
    private TextField customerNameField;
    @FXML
    private TextField customerAddressField;
    @FXML
    private TextField customerPostalField;
    @FXML
    private TextField customerPhoneField;
    @FXML
    public static boolean isAddingNewCustomer = false;
    @FXML
    public static boolean isAddingNewAppointment = false;

    /**
     * Initializes the main screen components, including tables and radio buttons.
     *
     * @throws SQLException If an SQL exception occurs.
     */
    @FXML
    public void initialize() throws SQLException {
        ObservableList<Appointments> allAppointmentsOL = appointmentsAccess.getAllAppointments();

        appointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        appointmentTitle.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        appointmentDescription.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        appointmentLocation.setCellValueFactory(new PropertyValueFactory<>("appointmentLocation"));
        appointmentType.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        appointmentStart.setCellValueFactory(new PropertyValueFactory<>("appointmentStartLocalFormatted"));
        appointmentEnd.setCellValueFactory(new PropertyValueFactory<>("appointmentEndLocalFormatted"));
        appointmentCustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        appointmentContact.setCellValueFactory(new PropertyValueFactory<>("contactID"));
        appointmentUserID.setCellValueFactory(new PropertyValueFactory<>("userID"));

        appointmentsTable.setItems(allAppointmentsOL);

        ObservableList<Customers> allCustomersOL = customersAccess.getAllCustomers();
        ObservableList<firstLevelDivisionsAccess> firstLevelDivisionsOL = firstLevelDivisionsAccess.getAllFirstLevelDivisions();

        customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        customerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        customerAddress.setCellValueFactory(new PropertyValueFactory<>("customerAddress"));
        customerPostalCode.setCellValueFactory(new PropertyValueFactory<>("customerPostalCode"));
        customerPhone.setCellValueFactory(new PropertyValueFactory<>("customerPhone"));
        customerDivision.setCellValueFactory(new PropertyValueFactory<>("customerDivision"));

        CustomersTable.setItems(allCustomersOL);
    }

    /**
     * Handles the selection of the "All Appointments" radio button.
     *
     * @param event The ActionEvent triggered by the radio button.
     * @throws SQLException If an SQL exception occurs.
     */
    @FXML
    void allAppointmentsRadioSelected(ActionEvent event) throws SQLException {
        try {
            ObservableList<Appointments> allAppointmentsOL = appointmentsAccess.getAllAppointments();

            if (allAppointmentsOL != null)
                for (Appointments appointment : allAppointmentsOL) {
                    appointmentsTable.setItems(allAppointmentsOL);
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the selection of the "Current Week" radio button.
     *
     * @param event The ActionEvent triggered by the radio button.
     * @throws SQLException If an SQL exception occurs.
     */
    @FXML
    void currentWeekRadioSelected(ActionEvent event) throws SQLException {
        try {

            ObservableList<Appointments> allAppointmentsOL = appointmentsAccess.getAllAppointments();
            ObservableList<Appointments> appointmentsWeek = FXCollections.observableArrayList();

            LocalDateTime weekStart = LocalDateTime.now().minusWeeks(1);
            LocalDateTime weekEnd = LocalDateTime.now().plusWeeks(1);

            if (allAppointmentsOL != null)
                allAppointmentsOL.forEach(appointment -> {
                    if (appointment.getAppointmentEnd().isAfter(weekStart) && appointment.getAppointmentEnd().isBefore(weekEnd)) {
                        appointmentsWeek.add(appointment);
                    }
                    appointmentsTable.setItems(appointmentsWeek);
                });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the selection of the "Current Month" radio button.
     *
     * @param event The ActionEvent triggered by the radio button.
     * @throws SQLException If an SQL exception occurs.
     */
    @FXML
    void currentMonthRadioSelected(ActionEvent event) throws SQLException {
        try {
            ObservableList<Appointments> allAppointmentsOL = appointmentsAccess.getAllAppointments();
            ObservableList<Appointments> appointmentsMonth = FXCollections.observableArrayList();

            LocalDateTime currentMonthStart = LocalDateTime.now().minusMonths(1);
            LocalDateTime currentMonthEnd = LocalDateTime.now().plusMonths(1);


            if (allAppointmentsOL != null)
                allAppointmentsOL.forEach(appointment -> {
                    if (appointment.getAppointmentEnd().isAfter(currentMonthStart) && appointment.getAppointmentEnd().isBefore(currentMonthEnd)) {
                        appointmentsMonth.add(appointment);
                    }
                });
            appointmentsTable.setItems(appointmentsMonth);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the "Add Appointment" button click event.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    private void handleAddAppointmentButton(ActionEvent event) {
        isAddingNewAppointment = true;
        try {
            // Load the appointmentScreen.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/appointmentScreen.fxml"));
            Parent root = loader.load();

            // Access the controller of the loaded FXML
            appointmentScreen appointmentController = loader.getController();

            // Pass the reference to the main screen controller
            appointmentController.setMainController(this);

            // Autofill the appointment ID
            appointmentController.autofillAppointmentID();

            // Create a new stage for the appointment screen
            Stage appointmentStage = new Stage();
            appointmentStage.setTitle("Add Appointment");  // Set the title as needed
            appointmentStage.setScene(new Scene(root));
            // Show the appointment screen
            appointmentStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    /**
     * Handles the "Update Appointment" button click event.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    private void handleUpdateAppointmentButton(ActionEvent event) {
        isAddingNewAppointment = false;

        try {
            // Load the appointmentScreen.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/appointmentScreen.fxml"));
            Parent root = loader.load();

            // Access the controller of the loaded FXML
            appointmentScreen appointmentController = loader.getController();

            // Pass the reference to the main screen controller
            appointmentController.setMainController(this);

            // Get the selected appointment
            Appointments selectedAppointment = appointmentsTable.getSelectionModel().getSelectedItem();

            if (selectedAppointment == null) {
                // Display an error message if no customer is selected
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please select an appointment to update.");
                alert.showAndWait();
                return; // Exit the method if no appointment is selected
            }

            // Pass data to appointmentController methods
            appointmentController.setSelectedAppointment(selectedAppointment);
            appointmentController.prefillFieldsWithAppointmentData(selectedAppointment);

            // Error if no customer is selected
            if (selectedAppointment == null) {
                System.out.println("No customer was selected");
            }

            // Create a new stage for the appointment screen
            Stage appointmentStage = new Stage();
            appointmentStage.setTitle("Update Appointment");  // Set the title as needed
            appointmentStage.setScene(new Scene(root));
            // Show the appointment screen
            appointmentStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception as needed
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Handles the "Delete Appointment" button click event.
     *
     * @param event The ActionEvent triggered by the button click.
     *
     * Lambda expression #1 to handle the delete appointment button
     */
    @FXML
    private void handleDeleteAppointmentButton(ActionEvent event) {
        // Get the selected appointment
        Appointments selectedAppointment = appointmentsTable.getSelectionModel().getSelectedItem();
        if (selectedAppointment == null) {
            // No appointment selected, show an alert
            new Alert(Alert.AlertType.INFORMATION, "Please select an appointment to delete.").showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Delete the selected appointment?");
        Optional<ButtonType> confirmation = alert.showAndWait();

        // Lambda expression #1
        confirmation.ifPresent(buttonType -> {
            if (buttonType == ButtonType.OK) {
                try {
                    // Delete the appointment
                    appointmentsAccess.deleteAppointment(selectedAppointment.getAppointmentID());
                    Alert confirmationAlert = new Alert(Alert.AlertType.INFORMATION);
                    confirmationAlert.setTitle("Appointment Deleted");
                    confirmationAlert.setHeaderText(null);
                    confirmationAlert.setContentText("Appointment ID " + selectedAppointment.getAppointmentID() + " - " + selectedAppointment.getAppointmentType() + " has been successfully deleted.");
                    confirmationAlert.showAndWait();

                    // Refresh the appointment table
                    refreshAppointmentTable();
                } catch (SQLException e) {
                    e.printStackTrace();
                    // Handle the exception as needed
                }
            }
        });
    }

    /**
     * Handles the "Add Customer" button click event.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    private void handleAddCustomerButton(ActionEvent event) {
        isAddingNewCustomer = true;
        try {
            // Load the customerScreen.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/customerScreen.fxml"));
            Parent root = loader.load();

            // Access the controller of the loaded FXML
            customerScreen customerController = loader.getController();

            // Pass the reference to the main screen controller
            customerController.setMainController(this);

            // Autofill the customer ID
            customerController.autofillCustomerID();

            // Create a new stage for the customer screen
            Stage customerStage = new Stage();
            customerStage.setTitle("Add Customer");  // Set the title as needed
            customerStage.setScene(new Scene(root));
            // Show the customer screen
            customerStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    /**
     * Handles the "Update Customer" button click event.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    private void handleUpdateCustomerButton(ActionEvent event) {
        isAddingNewCustomer = false;
        try {
            // Load the customerScreen.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/customerScreen.fxml"));
            Parent root = loader.load();

            // Access the controller of the loaded FXML
            customerScreen customerController = loader.getController();

            // Pass the reference to the main screen controller
            customerController.setMainController(this);

            // Get the selected Customer
            Customers selectedCustomer = CustomersTable.getSelectionModel().getSelectedItem();

            if (selectedCustomer == null) {
                // Display an error message if no customer is selected
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText(null);
                alert.setContentText("Please select a customer to update.");
                alert.showAndWait();
                return; // Exit the method if no appointment is selected
            }

            // Pass data to customerController methods
            customerController.setSelectedCustomer(selectedCustomer);
            customerController.prefillFieldsWithCustomerData(selectedCustomer);

            // Error if no customer is selected
            if (selectedCustomer == null) {
                System.out.println("No customer was selected");
            }

            int customerID = selectedCustomer.getCustomerID();
            String customerName = selectedCustomer.getCustomerName();
            String customerAddress = selectedCustomer.getCustomerAddress();

            // Create a new stage for the customer screen
            Stage customerStage = new Stage();
            customerStage.setTitle("Update Customer");  // Set the title as needed
            customerStage.setScene(new Scene(root));
            // Show the customer screen
            customerStage.show();

        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    private void handleCustomerSelection() {
        Customers selectedCustomer = CustomersTable.getSelectionModel().getSelectedItem();
    }

    /**
     * Handles the "Delete Customer" button click event.
     *
     * @param event The ActionEvent triggered by the button click.
     *
     * Lambda expression #2 to handle the delete customer button
     */
    @FXML
    private void handleDeleteCustomerButton(ActionEvent event) {
        // Get the selected customer
        Customers selectedCustomer = CustomersTable.getSelectionModel().getSelectedItem();
        if (selectedCustomer == null) {
            // No customer selected, show an alert
            new Alert(Alert.AlertType.INFORMATION, "Please select a customer to delete.").showAndWait();
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Delete the selected customer and all appointments?");
        Optional<ButtonType> confirmation = alert.showAndWait();

        // Lambda expression #2
        confirmation.ifPresent(buttonType -> {
            if (buttonType == ButtonType.OK) {
                try {
                    // Delete related appointments
                    appointmentsAccess.deleteAppointmentsByCustomer(selectedCustomer.getCustomerID());

                    // Delete the customer
                    customersAccess.deleteCustomer(selectedCustomer.getCustomerID());
                    Alert confirmationAlert = new Alert(Alert.AlertType.INFORMATION);
                    confirmationAlert.setTitle("Customer Deleted");
                    confirmationAlert.setHeaderText(null);
                    confirmationAlert.setContentText("Customer ID " + selectedCustomer.getCustomerID() + " and all associated appointments have been successfully deleted.");
                    confirmationAlert.showAndWait();

                    // Refresh the customers table
                    refreshCustomersTable();
                    refreshAppointmentTable();
                } catch (SQLException e) {
                    e.printStackTrace();
                    // Handle the exception as needed
                }
            }
        });
    }

    /**
     * Handles the "Reports" button click event.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    private void handleReportsButton (ActionEvent event) {
        try {
            // Load the reportScreen.fxml file
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/reportScreen.fxml"));
            Parent root = loader.load();

            // Create a new stage for the report screen
            Stage reportStage = new Stage();
            reportStage.setTitle("Reports");  // Set the title as needed
            reportStage.setScene(new Scene(root));
            // Show the report screen
            reportStage.show();
        } catch (IOException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }

    }

    /**
     * Handles the "Exit" button click event.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
        public void exitButton (ActionEvent event){
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

    /**
     * Refreshes the appointment table with the latest data.
     */
    @FXML
    //Method to refresh CustomersTable
    public void refreshAppointmentTable() {
        try {
            ObservableList<Appointments> allAppointmentsOL = appointmentsAccess.getAllAppointments();
            appointmentsTable.setItems(allAppointmentsOL);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    /**
     * Refreshes the customers table with the latest data.
     */
    @FXML
    //Method to refresh CustomersTable
    public void refreshCustomersTable() {
        try {
            ObservableList<Customers> allCustomersOL = customersAccess.getAllCustomers();
            CustomersTable.setItems(allCustomersOL);
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    /**
     * Gets the reference to the CustomersTable.
     *
     * @return The TableView of Customers.
     */
    @FXML
    public TableView<Customers> getCustomersTable() {
        return CustomersTable;
    }

}
