package controller;

import DAO.appointmentsAccess;
import DAO.contactsAccess;
import DAO.customersAccess;
import DAO.userAuthentication;
import helper.JDBC;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;
import model.Contacts;
import model.Customers;
import model.Users;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Optional;
import java.util.TimeZone;

/**
 * Controller class for the appointment screen.
 */
public class appointmentScreen {

    @FXML
    private TextField appointmentIDField;
    @FXML
    private TextField appointmentTitleField;
    @FXML
    private TextField appointmentTypeField;
    @FXML
    private TextField appointmentDescriptionField;
    @FXML
    private TextField appointmentLocationField;
    @FXML
    private TextField customerIDField;
    @FXML
    private TextField userIDField;
    @FXML
    private ComboBox<String> appointmentStartTimePicker;
    @FXML
    private ComboBox<String> appointmentEndTimePicker;
    @FXML
    private ComboBox<String> contactNamePicker;
    @FXML
    private DatePicker appointmentStartDatePicker;
    @FXML
    private DatePicker appointmentEndDatePicker;
    @FXML
    private Button appointmentCancelButton;
    @FXML
    private Button appointmentSaveButton;
    @FXML
    private mainScreen mainController;
    @FXML
    private Appointments selectedAppointment;
    @FXML
    private String displayContactName;
    @FXML
    private DateTimeFormatter minHourFormat;


    /**
     * Default Constructor
     */
    public appointmentScreen() {

    }

    /**
     * Constructor reference to mainScreen
     *
     * @param mainController Reference to the main controller.
     */
    public void setMainController(mainScreen mainController) {
        this.mainController = mainController;
    }

    /**
     * Method to set the selected appointment.
     *
     * @param appointment The selected appointment.
     */
    public void setSelectedAppointment(Appointments appointment) {
        this.selectedAppointment = appointment;
    }

    /**
     * Autofills the appointment ID field with the next available ID from the database.
     * Retrieves the next available appointment ID from the database using the DAO class
     * and sets the appointment ID in the corresponding text field.
     */
    @FXML
    public void autofillAppointmentID() {

        try {
            // Get the next available appointment ID from the database using the DAO class
            int nextAppointmentID = appointmentsAccess.getNextAppointmentID();

            // Autofill the appointment ID in the text field
            appointmentIDField.setText(String.valueOf(nextAppointmentID));
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }

    }

    /**
     * Initialize method for JavaFX.
     *
     * @throws SQLException If a SQL exception occurs.
     */
    @FXML
    public void initialize() throws SQLException {

        ObservableList<Contacts> contactsOL = contactsAccess.getAllContacts();
        ObservableList<String> allContactsNames = FXCollections.observableArrayList();
        ObservableList<String> appointmentTimes = FXCollections.observableArrayList();

        for (Contacts contacts : contactsOL) {
            allContactsNames.add(contacts.getContactName());
        }

        LocalTime firstAppointment = LocalTime.MIN.plusHours(8);
        LocalTime lastAppointment = LocalTime.MAX.minusHours(1).minusMinutes(45);

        if (!firstAppointment.equals(0) || !lastAppointment.equals(0)) {
            while (firstAppointment.isBefore(lastAppointment)) {
                appointmentTimes.add(String.valueOf(firstAppointment));
                firstAppointment = firstAppointment.plusMinutes(15);
            }
        }

        appointmentStartTimePicker.setItems(appointmentTimes);
        appointmentEndTimePicker.setItems(appointmentTimes);
        contactNamePicker.setItems(allContactsNames);

        minHourFormat = DateTimeFormatter.ofPattern("HH:mm");

    }

    /**
     * Action method for the appointment save button.
     *
     * @param event The action event.
     * @throws SQLException If a SQL exception occurs.
     */
    @FXML
    private void appointmentSaveButtonAction(ActionEvent event) throws SQLException {
        if (mainController.isAddingNewAppointment) {
            handleAddAppointment(event);
        } else {
            handleUpdateAppointment(event);
        }
    }

    /**
     * Validates the appointment time.
     *
     * @param start The start date and time.
     * @param end   The end date and time.
     * @return True if the appointment time is valid, false otherwise.
     * @throws SQLException If a SQL exception occurs.
     */
    @FXML
    private boolean validateAppointmentTime(LocalDateTime start, LocalDateTime end) throws SQLException {
        try {

        ObservableList<Appointments> getAllAppointments = appointmentsAccess.getAllAppointments();

        LocalDate localDateStart = appointmentStartDatePicker.getValue();
        LocalDate localDateEnd = appointmentEndDatePicker.getValue();

        LocalTime localStartTime = LocalTime.parse(appointmentStartTimePicker.getValue(), minHourFormat);
        LocalTime LocalEndTime = LocalTime.parse(appointmentEndTimePicker.getValue(), minHourFormat);

        LocalDateTime localDateTimeStart = LocalDateTime.of(localDateStart, localStartTime);
        LocalDateTime localDateTimeEnd = LocalDateTime.of(localDateEnd, LocalEndTime);

        ZonedDateTime zoneDtStart = ZonedDateTime.of(localDateTimeStart, ZoneId.systemDefault());
        ZonedDateTime zoneDtEnd = ZonedDateTime.of(localDateTimeEnd, ZoneId.systemDefault());

        ZonedDateTime convertStartEST = zoneDtStart.withZoneSameInstant(ZoneId.of("America/New_York"));
        ZonedDateTime convertEndEST = zoneDtEnd.withZoneSameInstant(ZoneId.of("America/New_York"));

        LocalTime startAppointmentTimeCheck = convertStartEST.toLocalTime();
        LocalTime endAppointmentTimeCheck = convertEndEST.toLocalTime();

        DayOfWeek startAppointmentDayCheck = convertStartEST.toLocalDate().getDayOfWeek();
        DayOfWeek endAppointmentDayCheck = convertEndEST.toLocalDate().getDayOfWeek();

        int startAppointmentDayCheckInt = startAppointmentDayCheck.getValue();
        int endAppointmentDayCheckInt = endAppointmentDayCheck.getValue();

        int workWeekStart = DayOfWeek.MONDAY.getValue();
        int workWeekEnd = DayOfWeek.FRIDAY.getValue();

        LocalTime estBusinessStart = LocalTime.of(8, 0, 0);
        LocalTime estBusinessEnd = LocalTime.of(22, 0, 0);

        if (startAppointmentDayCheckInt < workWeekStart || startAppointmentDayCheckInt > workWeekEnd || endAppointmentDayCheckInt < workWeekStart || endAppointmentDayCheckInt > workWeekEnd) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Day is outside of business operations (Monday-Friday)");
            Optional<ButtonType> confirmation = alert.showAndWait();
            System.out.println("day is outside of business hours");
            return false;
        }

        if (startAppointmentTimeCheck.isBefore(estBusinessStart) || startAppointmentTimeCheck.isAfter(estBusinessEnd) || endAppointmentTimeCheck.isBefore(estBusinessStart) || endAppointmentTimeCheck.isAfter(estBusinessEnd)) {
            System.out.println("time is outside of business hours");
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Time is outside of business hours (8am-10pm EST): " + startAppointmentTimeCheck + " - " + endAppointmentTimeCheck + " EST");
            Optional<ButtonType> confirmation = alert.showAndWait();
            return false;
        }

        int appointmentID = Integer.parseInt(appointmentIDField.getText());
        int customerID = Integer.parseInt(customerIDField.getText());

        if (localDateTimeStart.isAfter(localDateTimeEnd)) {
            System.out.println("Appointment has start time after end time");
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Appointment has start time after end time");
            Optional<ButtonType> confirmation = alert.showAndWait();
            return false;
        }

        if (localDateTimeStart.isEqual(localDateTimeEnd)) {
            System.out.println("Appointment has same start and end time");
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Appointment has same start and end time");
            Optional<ButtonType> confirmation = alert.showAndWait();
            return false;
        }

            ZoneId localTimeZone = ZoneId.systemDefault();

            for (Appointments existing : getAllAppointments) {
                // Convert existing appointment times to local time (machine's time zone)
                LocalDateTime existingStart = existing.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(localTimeZone).toLocalDateTime();
                LocalDateTime existingEnd = existing.getEnd().atZone(ZoneOffset.UTC).withZoneSameInstant(localTimeZone).toLocalDateTime();

                if (customerID == existing.getCustomerID() && appointmentID != existing.getAppointmentID()) {
                    // Check for overlap
                    if (localDateTimeStart.isBefore(existingEnd) && localDateTimeEnd.isAfter(existingStart)) {
                        // New appointment overlaps existing
                        System.out.println("Appointment overlaps with existing appointment");
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Appointment overlaps with existing appointment");
                        Optional<ButtonType> confirmation = alert.showAndWait();
                        return false;
                    }

                    // Check start overlap
                    else if (localDateTimeStart.isAfter(existingStart) && localDateTimeStart.isBefore(existingEnd)) {
                        // New start overlaps
                        System.out.println("Start time overlaps with existing appointment");
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Start time overlaps with existing appointment");
                        Optional<ButtonType> confirmation = alert.showAndWait();
                        return false;
                    }

                    // Check end overlap
                    else if (localDateTimeEnd.isAfter(existingStart) && localDateTimeEnd.isBefore(existingEnd)) {
                        // New end overlaps
                        System.out.println("End time overlaps with existing appointment");
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "End time overlaps with existing appointment");
                        Optional<ButtonType> confirmation = alert.showAndWait();
                        return false;
                    }
                }
            }
            return true;
        } catch (SQLException e) {
            // Handle SQL errors
            Alert alert = new Alert(Alert.AlertType.ERROR, "An error occurred while retrieving appointments: " + e.getMessage());
            alert.showAndWait();
            return false;
        }
    }

    /**
     * Handles the addition of a new appointment.
     *
     * @param event The action event.
     */
    @FXML
    void handleAddAppointment(ActionEvent event) {

        try {

            Connection connection = JDBC.openConnection();

            if (!appointmentTitleField.getText().isEmpty() && !appointmentDescriptionField.getText().isEmpty() && !appointmentLocationField.getText().isEmpty() && !appointmentTypeField.getText().isEmpty() && appointmentStartDatePicker.getValue() != null && appointmentEndDatePicker.getValue() != null && !appointmentStartTimePicker.getValue().isEmpty() && !appointmentEndTimePicker.getValue().isEmpty() && !customerIDField.getText().isEmpty()) {

                ObservableList<Customers> getAllCustomers = customersAccess.getAllCustomers();
                ObservableList<Integer> storeCustomerIDList = FXCollections.observableArrayList();
                ObservableList<userAuthentication> getAllUsers = userAuthentication.getAllUsers();
                ObservableList<Integer> storeUserIDList = FXCollections.observableArrayList();
                ObservableList<Appointments> getAllAppointments = appointmentsAccess.getAllAppointments();

                getAllCustomers.stream().map(Customers::getCustomerID).forEach(storeCustomerIDList::add);
                getAllUsers.stream().map(Users::getUserID).forEach(storeUserIDList::add);

                // Gather appointment details
                LocalDate localDateStart = appointmentStartDatePicker.getValue();
                LocalDate localDateEnd = appointmentEndDatePicker.getValue();
                // ... (Gather other fields)

                // Construct LocalDateTime objects for validation
                LocalDateTime startDateTime = LocalDateTime.of(localDateStart, LocalTime.parse(appointmentStartTimePicker.getValue(), minHourFormat));
                LocalDateTime endDateTime = LocalDateTime.of(localDateEnd, LocalTime.parse(appointmentEndTimePicker.getValue(), minHourFormat));

                // Validate appointment time
                if (!validateAppointmentTime(startDateTime, endDateTime)) {
                    return; // Exit if validation fails
                }

                startDateTime = LocalDateTime.of(appointmentStartDatePicker.getValue(),
                        LocalTime.parse(appointmentStartTimePicker.getValue()));
                endDateTime = LocalDateTime.of(appointmentEndDatePicker.getValue(),
                        LocalTime.parse(appointmentEndTimePicker.getValue()));

                ZonedDateTime startUTC = ZonedDateTime.of(startDateTime, ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));
                ZonedDateTime endUTC = ZonedDateTime.of(endDateTime, ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));

                // Get current UTC timestamp
                Instant currentInstant = Instant.now();
                // Explicitly create a ZonedDateTime object with the UTC time zone
                ZonedDateTime currentUTCDateTime = ZonedDateTime.ofInstant(currentInstant, ZoneId.of("UTC"));
                // Convert to current Timestamp
                Timestamp currentTimestamp = Timestamp.valueOf(currentUTCDateTime.toLocalDateTime());


                String insertStatement = "INSERT INTO appointments (Appointment_ID, Title, Description, Location, Type, Start, End, Create_Date, Created_By, Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

                PreparedStatement ps = connection.prepareStatement(insertStatement);
                int appointmentId = Integer.parseInt(appointmentIDField.getText());
                ps.setInt(1, appointmentId);
                ps.setString(2, appointmentTitleField.getText());
                ps.setString(3, appointmentDescriptionField.getText());
                ps.setString(4, appointmentLocationField.getText());
                ps.setString(5, appointmentTypeField.getText());
                ps.setTimestamp(6, Timestamp.from(startUTC.toInstant()), Calendar.getInstance(TimeZone.getTimeZone("UTC")));
                ps.setTimestamp(7, Timestamp.from(endUTC.toInstant()), Calendar.getInstance(TimeZone.getTimeZone("UTC")));
                ps.setTimestamp(8, currentTimestamp);
                ps.setString(9, "admin");
                ps.setTimestamp(10, currentTimestamp);
                ps.setInt(11, 1);
                ps.setInt(12, Integer.parseInt(customerIDField.getText()));
                ps.setInt(13, Integer.parseInt(contactsAccess.findContactID(userIDField.getText())));
                ps.setInt(14, Integer.parseInt(contactsAccess.findContactID(contactNamePicker.getValue())));
                ps.execute();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Please fill out all fields");
                alert.showAndWait();
                return;
            }

            // Refresh table and close window
            mainController.refreshAppointmentTable();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    /**
     * Prefills fields with appointment data.
     *
     * @param appointment The appointment to prefill fields with.
     * @throws SQLException If a SQL exception occurs.
     */
    @FXML
    public void prefillFieldsWithAppointmentData(Appointments appointment) throws SQLException {
        ObservableList<Contacts> contactsOL = contactsAccess.getAllContacts();
        ObservableList<String> allContactsNames = FXCollections.observableArrayList();
        String displayContactName = "";

        for (Contacts contacts : contactsOL) {
            allContactsNames.add(contacts.getContactName());
        }
        contactNamePicker.setItems(allContactsNames);

        for (Contacts contact : contactsOL) {
            if (selectedAppointment.getContactID() == contact.getContactID()) {
                displayContactName = contact.getContactName();
            }
        }

        try (Connection connection = JDBC.openConnection()) {
            appointmentIDField.setText(String.valueOf(appointment.getAppointmentID()));
            appointmentTitleField.setText(appointment.getAppointmentTitle());
            appointmentTypeField.setText(appointment.getAppointmentType());
            appointmentDescriptionField.setText(appointment.getAppointmentDescription());
            appointmentLocationField.setText(appointment.getAppointmentLocation());

            // Convert database timestamps to user's local time
            ZonedDateTime startLocal = appointment.getAppointmentStart().atZone(ZoneId.of("UTC")).withZoneSameInstant(ZoneId.systemDefault());
            ZonedDateTime endLocal = appointment.getAppointmentEnd().atZone(ZoneId.of("UTC")).withZoneSameInstant(ZoneId.systemDefault());

            appointmentStartDatePicker.setValue(startLocal.toLocalDate());
            appointmentStartTimePicker.setValue(String.valueOf(startLocal.toLocalTime()));

            appointmentEndDatePicker.setValue(endLocal.toLocalDate());
            appointmentEndTimePicker.setValue(String.valueOf(endLocal.toLocalTime()));

            customerIDField.setText(String.valueOf(appointment.getCustomerID()));
            userIDField.setText(String.valueOf(appointment.getUserID()));
            contactNamePicker.setValue(displayContactName);

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    /**
     * Handles the update of an existing appointment.
     *
     * @param event The action event.
     * @throws SQLException If a SQL exception occurs.
     */
    @FXML
    void handleUpdateAppointment(ActionEvent event) throws SQLException {
        Connection connection = JDBC.openConnection();
        String updateStatement = "UPDATE appointments SET"; // Initialize the statement

        if (!appointmentTitleField.getText().isEmpty() && !appointmentDescriptionField.getText().isEmpty() && !appointmentLocationField.getText().isEmpty() && !appointmentTypeField.getText().isEmpty() && appointmentStartDatePicker.getValue() != null && appointmentEndDatePicker.getValue() != null && !appointmentStartTimePicker.getValue().isEmpty() && !appointmentEndTimePicker.getValue().isEmpty() && !customerIDField.getText().isEmpty()) {

            LocalDateTime startDateTime = LocalDateTime.of(appointmentStartDatePicker.getValue(),
                    LocalTime.parse(appointmentStartTimePicker.getValue()));
            LocalDateTime endDateTime = LocalDateTime.of(appointmentEndDatePicker.getValue(),
                    LocalTime.parse(appointmentEndTimePicker.getValue()));

            ZonedDateTime startUTC = ZonedDateTime.of(startDateTime, ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));
            ZonedDateTime endUTC = ZonedDateTime.of(endDateTime, ZoneId.systemDefault()).withZoneSameInstant(ZoneId.of("UTC"));

            // Check each field and add it to the statement if it needs to be updated
            if (!appointmentTitleField.getText().equals(selectedAppointment.getAppointmentTitle())) {
                updateStatement += " Title = ?,";
            }
            if (!appointmentTypeField.getText().equals(selectedAppointment.getAppointmentType())) {
                updateStatement += " Type = ?,";
            }
            if (!appointmentDescriptionField.getText().equals(selectedAppointment.getAppointmentDescription())) {
                updateStatement += " Description = ?,";
            }
            if (!appointmentLocationField.getText().equals(selectedAppointment.getAppointmentLocation())) {
                updateStatement += " Location = ?,";
            }
            updateStatement += " Start = ?,";
            updateStatement += " End = ?,";
            if (!customerIDField.getText().equals(String.valueOf(selectedAppointment.getCustomerID()))) {
                updateStatement += " Customer_ID = ?,";
            }
            if (!userIDField.getText().equals(String.valueOf(selectedAppointment.getUserID()))) {
                updateStatement += " User_ID = ?,";
            }
            if (!contactNamePicker.getValue().equals(displayContactName)) {
                updateStatement += " Contact_ID = ?,";
                int contactID = Integer.parseInt(contactsAccess.findContactID(contactNamePicker.getValue()));
            }

            // Remove the trailing comma if any fields are added to the statement
            if (updateStatement.endsWith(",")) {
                updateStatement = updateStatement.substring(0, updateStatement.length() - 1);
            }

            if (!validateAppointmentTime(startDateTime, endDateTime)) {
                return; // Exit if validation fails
            }

            // Add the WHERE clause to the statement
            updateStatement += " WHERE Appointment_ID = ?";

            // Execute UPDATE statement if it was constructed
            if (updateStatement.contains("=")) {
                try (PreparedStatement ps = connection.prepareStatement(updateStatement)) {
                    int appointmentID = Integer.parseInt(appointmentIDField.getText());
                    int parameterIndex = 1;

                    // Set parameters based on the specific fields being updated
                    if (updateStatement.contains("Title")) {
                        ps.setString(parameterIndex++, appointmentTitleField.getText());
                    }
                    if (updateStatement.contains("Type")) {
                        ps.setString(parameterIndex++, appointmentTypeField.getText());
                    }
                    if (updateStatement.contains("Description")) {
                        ps.setString(parameterIndex++, appointmentDescriptionField.getText());
                    }
                    if (updateStatement.contains("Location")) {
                        ps.setString(parameterIndex++, appointmentLocationField.getText());
                    }
                    if (updateStatement.contains("Start")) {
                        ps.setTimestamp(parameterIndex++, Timestamp.from(startUTC.toInstant()), Calendar.getInstance(TimeZone.getTimeZone("UTC")));
                    }
                    if (updateStatement.contains("End")) {
                        ps.setTimestamp(parameterIndex++, Timestamp.from(endUTC.toInstant()), Calendar.getInstance(TimeZone.getTimeZone("UTC")));
                    }
                    if (updateStatement.contains("Customer_ID")) {
                        ps.setInt(parameterIndex++, Integer.parseInt(customerIDField.getText()));
                    }
                    if (updateStatement.contains("User_ID")) {
                        ps.setInt(parameterIndex++, Integer.parseInt(userIDField.getText()));
                    }
                    if (updateStatement.contains("Contact_ID")) {
                        ps.setInt(parameterIndex++, Integer.parseInt(contactsAccess.findContactID(contactNamePicker.getValue())));
                    }


                    ps.setInt(parameterIndex, appointmentID); // Set Appointment_ID for WHERE clause
                    ps.execute();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }

            // Refresh table and close window
            mainController.refreshAppointmentTable();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR, "Please fill out all fields");
            alert.showAndWait();
            return;}
    }

    /**
     * Action method for the appointment cancel button.
     *
     * @param event The action event.
     */
    @FXML
    private void appointmentCancelButtonHandler(ActionEvent event) {
        // Close the stage when the cancel button is clicked
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();

    }
}
