package controller;

import DAO.appointmentsAccess;
import DAO.userAuthentication;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Appointments;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller class for the login screen of the Appointment Application.
 * Handles user authentication, login actions, and displays relevant information.
 * Implements Initializable to provide initialization logic during FXML loading.
 */
public class loginScreen implements Initializable {

        @FXML
        private PasswordField passwordField;
        @FXML
        private TextField usernameField;
        @FXML
        private TextField loginLocationField;
        @FXML
        private Label passwordLabel;
        @FXML
        private Label usernameLabel;
        @FXML
        private Label locationLabel;
        @FXML
        private Button exitButton;
        @FXML
        private Button loginButton;
        @FXML
        private Label loginLabel;
        private DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

        Stage stage;

        /**
         * Initializes the login screen controller.
         *
         * @param location The location used to resolve relative paths for the root object, or null if the location is not known.
         * @param rb       The resources used to localize the root object, or null if the root object was not localized.
         */
        @FXML
        @Override
        public void initialize(URL location, ResourceBundle rb) {
                try {
                        // This line retrieves a ResourceBundle named "login" from the "language" package
                        rb = ResourceBundle.getBundle("language/login", Locale.getDefault());

                        // Get the system's default time zone
                        ZoneId zone = ZoneId.systemDefault();
                        // Set the time zone ID as the text of the location field
                        loginLocationField.setText(zone.getId());
                        loginLabel.setText(rb.getString("Login"));
                        usernameLabel.setText(rb.getString("Username"));
                        passwordLabel.setText(rb.getString("Password"));
                        loginButton.setText(rb.getString("Login"));
                        exitButton.setText(rb.getString("Exit"));
                        locationLabel.setText(rb.getString("Location"));

                } catch (MissingResourceException e) {
                        System.out.println("Resource file missing: " + e);
                } catch (Exception e)
                {
                        System.out.println(e);
                }
        }

        /**
         * Handles the action when the "Login" button is clicked.
         *
         * @param event The ActionEvent triggered by the button click.
         * @throws SQLException If an SQL exception occurs.
         * @throws IOException  If an I/O exception occurs.
         * @throws Exception    If a general exception occurs.
         */
        @FXML
        public void loginButton(ActionEvent event) throws SQLException, IOException, Exception {
                try {

                ObservableList<Appointments> getAllAppointments = appointmentsAccess.getAllAppointments();
                LocalDateTime currentTimeMinus15Min = LocalDateTime.now().minusMinutes(15);
                LocalDateTime currentTimePlus15Min = LocalDateTime.now().plusMinutes(15);
                ZoneId localTimeZone = ZoneId.systemDefault();
                LocalDateTime startTime;
                int getAppointmentID = 0;
                LocalDateTime displayTime = null;
                boolean appointmentWithin15Min = false;

                ResourceBundle rb = ResourceBundle.getBundle("language/login", Locale.getDefault());

                String usernameInput = usernameField.getText();
                String passwordInput = passwordField.getText();
                int userId = userAuthentication.authenticateUser(usernameInput, passwordInput);

                // Create Log
                FileWriter fileWriter = new FileWriter("login_activity.txt", true);
                PrintWriter outputFile = new PrintWriter(fileWriter);

                if (userId > 0) {
                        FXMLLoader loader = new FXMLLoader();
                        loader.setLocation(getClass().getResource("/views/mainScreen.fxml"));
                        Parent root = loader.load();
                        stage = (Stage) loginButton.getScene().getWindow();
                        Scene scene = new Scene(root);
                        stage.setScene(scene);
                        stage.show();
                        System.out.println("Successful Login");

                        //log the successful login
                        outputFile.print(usernameInput + " successfully logged in at: " + Timestamp.valueOf(LocalDateTime.now()) + "\n");

                        // Check for upcoming appointments if user is validated
                        for (Appointments appointment : getAllAppointments) {
                                if (appointment.getUserID() == userId) {
                                        startTime = appointment.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(localTimeZone).toLocalDateTime();
                                        if ((startTime.isAfter(currentTimeMinus15Min) || startTime.isEqual(currentTimeMinus15Min))
                                                && (startTime.isBefore(currentTimePlus15Min) || startTime.isEqual(currentTimePlus15Min))) {
                                                getAppointmentID = appointment.getAppointmentID();
                                                displayTime = startTime;
                                                appointmentWithin15Min = true;
                                                break; // Exit the loop after finding an appointment
                                        }
                                }
                        }

                        if (appointmentWithin15Min) {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION, "You have an appointment within 15 minutes\n" +
                                        "Appointment ID: " + getAppointmentID + "\n" +
                                        "Appointment start time: " + displayTime);
                                Optional<ButtonType> confirmation = alert.showAndWait();
                                System.out.println("There is an appointment within 15 minutes");
                        } else {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION, "No upcoming appointments.");
                                Optional<ButtonType> confirmation = alert.showAndWait();
                                System.out.println("No upcoming appointments");
                        }

                } else if (userId < 0) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle(rb.getString("Error"));
                        alert.setContentText(rb.getString("Incorrect"));
                        alert.show();
                        System.out.println("Failed Login");

                        //log the failed login attempt
                        outputFile.print(usernameInput + " failed login attempt at: " + Timestamp.valueOf(LocalDateTime.now()) + "\n");
                }
                outputFile.close();
                } catch (IOException ioException) {
                        ioException.printStackTrace();
                }
        }

        /**
         * Handles the action when the "Exit" button is clicked.
         *
         * @param event The ActionEvent triggered by the button click.
         */
        @FXML
        public void exitButton(ActionEvent event) {
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.close();
        }
}
