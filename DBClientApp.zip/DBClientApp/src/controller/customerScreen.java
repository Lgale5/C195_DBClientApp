package controller;

import DAO.countryAccess;
import DAO.customersAccess;
import DAO.firstLevelDivisionsAccess;
import helper.JDBC;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Country;
import model.Customers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * Controller class for the customer screen of the Appointment Application.
 * Handles actions, data initialization, and interaction with the main screen controller.
 */
public class customerScreen {

    @FXML
    private TextField customerIDField;

    @FXML
    private TextField customerNameField;

    @FXML
    private TextField customerAddressField;

    @FXML
    private TextField customerPostalField;

    @FXML
    private TextField customerPhoneField;

    @FXML
    private ComboBox<String> customerCountryPicker;

    @FXML
    private ComboBox<String> customerStatePicker;
    @FXML
    private Button customerCancelButton;
    @FXML
    private Button customerSaveButton;
    @FXML
    private mainScreen mainController;
    @FXML
    private Customers selectedCustomer;

    /**
     * Default constructor for the customer screen controller.
     */
    public customerScreen() {

    }

    /**
     * Default constructor for the customer screen controller.
     */
    public customerScreen(mainScreen mainController) {
        this.mainController = mainController;
    }

    /**
     * Sets the selected customer for the controller.
     *
     * @param customer The selected customer.
     */
    public void setSelectedCustomer(Customers customer) {
        this.selectedCustomer = customer;
    }

    /**
     * Autofills the customer ID based on the next available ID from the database.
     */
    @FXML
    public void autofillCustomerID() {
        try {
            // Get the next available customer ID from the database using the DAO class
            int nextCustomerID = customersAccess.getNextCustomerID();

            // Autofill the customer ID in the text field
            customerIDField.setText(String.valueOf(nextCustomerID));
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    /**
     * Initializes the customer screen controller.
     *
     * Lambda expression #3  listener for the value of the country picker
     */
    @FXML
    public void initialize() {
        try {
            // Populate the country picker
            ObservableList<String> countries = countryAccess.getCountries();
            customerCountryPicker.setItems(countries);

            // Set a listener to the country picker to update the state picker based on the selected country
            // Lambda expression #3
            customerCountryPicker.valueProperty().addListener((observable, oldValue, newValue) -> {
                try {
                    // Get the list of states/provinces based on the selected country
                    ObservableList<String> states = firstLevelDivisionsAccess.getStatesByCountry(newValue);
                    customerStatePicker.setItems(states);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Handles the action when the "Save" button is clicked.
     * Determines whether to add new customer when selecting save, or modifying existing customer.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    private void customerSaveButtonAction(ActionEvent event) {
        if (mainController.isAddingNewCustomer) {
            customerRecordsAddCustomer(event);
        } else {
            handleUpdateCustomer(event);
        }
    }

    /**
     * Handles the action when the "Add Customer" button is clicked.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    void customerRecordsAddCustomer(ActionEvent event) {
        try (Connection connection = JDBC.openConnection()) {
            if (!customerNameField.getText().isEmpty() || !customerAddressField.getText().isEmpty()
                    || !customerIDField.getText().isEmpty() || !customerPostalField.getText().isEmpty()
                    || !customerPhoneField.getText().isEmpty() || !customerCountryPicker.getValue().isEmpty()
                    || !customerStatePicker.getValue().isEmpty()) {

                int firstLevelDivisionName = 0;
                for (firstLevelDivisionsAccess firstLevelDivision : firstLevelDivisionsAccess.getAllFirstLevelDivisions()) {
                    if (customerStatePicker.getSelectionModel().getSelectedItem()
                            .equals(firstLevelDivision.getDivision())) {
                        firstLevelDivisionName = firstLevelDivision.getDivisionID();

                        String insertStatement = "INSERT INTO customers (Customer_ID, Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, Last_Updated_By, Division_ID) VALUES (?,?,?,?,?,?,?,?,?,?)";
                        try (PreparedStatement ps = connection.prepareStatement(insertStatement)) {
                            int customerId = Integer.parseInt(customerIDField.getText());
                            ps.setInt(1, customerId);
                            ps.setString(2, customerNameField.getText());
                            ps.setString(3, customerAddressField.getText());
                            ps.setString(4, customerPostalField.getText());
                            ps.setString(5, customerPhoneField.getText());
                            ps.setTimestamp(6, Timestamp.valueOf(LocalDateTime.now()));
                            ps.setString(7, "admin");
                            ps.setTimestamp(8, Timestamp.valueOf(LocalDateTime.now()));
                            ps.setString(9, "admin");
                            ps.setInt(10, firstLevelDivisionName);
                            ps.execute();
                        }
                    }
                }
            }

            // On Event Trigger, refresh Customers Table
            mainController.refreshCustomersTable();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    /**
     * Prefills the input fields with data from the selected customer.
     *
     * @param customer The selected customer.
     */
    @FXML
    public void prefillFieldsWithCustomerData(Customers customer)
    // Error if no customer is selected
    {
        {
            try (Connection connection = JDBC.openConnection()) {
                int divisionID = customer.getCustomerDivisionID();
                Country country = firstLevelDivisionsAccess.getCountryByDivisionID(divisionID);

                customerIDField.setText(String.valueOf(customer.getCustomerID()));
                customerNameField.setText(customer.getCustomerName());
                customerAddressField.setText(customer.getCustomerAddress());
                customerPhoneField.setText(customer.getCustomerPhone());
                customerPostalField.setText(customer.getCustomerPostalCode());
                customerStatePicker.setValue(customer.getCustomerDivision());
                customerCountryPicker.setValue(country.getCountryName());
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as needed
            }
        }
    }

    /**
     * Handles the action when the "Update Customer" button is clicked.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    void handleUpdateCustomer(ActionEvent event) {
        try {
            Connection connection = JDBC.openConnection();

            String updateStatement = "UPDATE customers SET"; // Initialize the statement
            int divisionID = 0;

            // Check each field and add it to the statement if it needs to be updated
            if (!customerNameField.getText().equals(selectedCustomer.getCustomerName())) {
                updateStatement += " Customer_Name = ?,";
            }
            if (!customerAddressField.getText().equals(selectedCustomer.getCustomerAddress())) {
                updateStatement += " Address = ?,";
            }
            if (!customerPostalField.getText().equals(selectedCustomer.getCustomerPostalCode())) {
                updateStatement += " Postal_Code = ?,";
            }
            if (!customerPhoneField.getText().equals(selectedCustomer.getCustomerPhone())) {
                updateStatement += " Phone = ?,";
            }
            if (!customerStatePicker.getSelectionModel().getSelectedItem().equals(selectedCustomer.getCustomerDivision())) {
                for (firstLevelDivisionsAccess firstLevelDivision : firstLevelDivisionsAccess.getAllFirstLevelDivisions()) {
                    if (customerStatePicker.getSelectionModel().getSelectedItem().equals(firstLevelDivision.getDivision())) {
                        divisionID = firstLevelDivision.getDivisionID();
                        updateStatement += " Division_ID = ?,";
                    }
                }
            }

            // Remove the trailing comma if any fields are added to the statement
            if (updateStatement.endsWith(",")) {
                updateStatement = updateStatement.substring(0, updateStatement.length() - 1);
            }

            // Add the WHERE clause to the statement
            updateStatement += " WHERE Customer_ID = ?";

            // Execute UPDATE statement if it was constructed
            if (updateStatement.contains("=")) {
                try (PreparedStatement ps = connection.prepareStatement(updateStatement)) {
                    int customerId = Integer.parseInt(customerIDField.getText());
                    int parameterIndex = 1;

                    // Set parameters based on the specific fields being updated
                    if (updateStatement.contains("Customer_Name")) {
                        ps.setString(parameterIndex++, customerNameField.getText());
                    }
                    if (updateStatement.contains("Address")) {
                        ps.setString(parameterIndex++, customerAddressField.getText());
                    }
                    if (updateStatement.contains("Postal_Code")) {
                        ps.setString(parameterIndex++, customerPostalField.getText());
                    }
                    if (updateStatement.contains("Phone")) {
                        ps.setString(parameterIndex++, customerPhoneField.getText());
                    }
                    if (updateStatement.contains("Division_ID")) {
                        ps.setInt(parameterIndex++, divisionID);
                    }

                    ps.setInt(parameterIndex, customerId); // Set Customer_ID for WHERE clause
                    ps.execute();
                }
            }

            // Refresh table and close window
            mainController.refreshCustomersTable();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    /**
     * Sets the reference to the main screen controller.
     *
     * @param mainController Reference to the main screen controller.
     */
    @FXML
    public void setMainController(mainScreen mainController) {
        this.mainController = mainController;
    }

    /**
     * Handles the action when the "Cancel" button is clicked.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    private void customerCancelButtonHandler(ActionEvent event) {
        // Close the stage when the cancel button is clicked
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();

    }

}


