package controller;

import DAO.appointmentsAccess;
import DAO.contactsAccess;
import DAO.customersAccess;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointments;
import model.Contacts;
import model.Customers;
import model.Report;

import java.sql.SQLException;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Controller class for the report screen of the Appointment Application.
 * Handles the display of various reports such as total appointments, appointments by contact,
 * and customer locations. Implements JavaFX FXML controllers for interaction with UI components.
 */
public class reportScreen {
    @FXML
    private TableView<Appointments> allAppointmentsTable;
    @FXML
    private Tab totalAppointmentsTab;
    @FXML
    private TableColumn<?, ?> appointmentID;
    @FXML
    private TableColumn<?, ?> appointmentTitle;
    @FXML
    private TableColumn<?, ?> appointmentType;
    @FXML
    private TableColumn<?, ?> appointmentDescription;
    @FXML
    private TableColumn<?, ?> appointmentStart;
    @FXML
    private TableColumn<?, ?> appointmentEnd;
    @FXML
    private TableColumn<?, ?> customerID;
    @FXML
    private TableView<Report> appointmentTypeTotalTable;
    @FXML
    private TableView<Report> appointmentMonthTotalTable;
    @FXML
    private TableColumn<?, ?> totalsAppointmentTypeColumn;
    @FXML
    private TableColumn<?, ?> totalsAppointmentMonthColumn;
    @FXML
    private TableColumn<?, ?> totalsAppointmentMonthTotalColumn;
    @FXML
    private TableColumn<?, ?> totalsAppointmentTypeTotalColumn;
    @FXML
    private TableView<Report> customerLocationTotalTable;
    @FXML
    private TableColumn<?, ?> customerState;
    @FXML
    private TableColumn<?, ?> customerStateTotal;
    @FXML
    private Button reportExitButton;
    @FXML
    private ChoiceBox contactScheduleChoice;

    /**
     * Initializes the report screen controller and sets up the necessary components.
     *
     * @throws SQLException If an SQL exception occurs during initialization.
     */
    @FXML
    public void initialize() throws SQLException {

        appointmentID.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        appointmentTitle.setCellValueFactory(new PropertyValueFactory<>("appointmentTitle"));
        appointmentType.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        appointmentDescription.setCellValueFactory(new PropertyValueFactory<>("appointmentDescription"));
        appointmentStart.setCellValueFactory(new PropertyValueFactory<>("appointmentStartLocalFormatted"));
        appointmentEnd.setCellValueFactory(new PropertyValueFactory<>("appointmentEndLocalFormatted"));
        customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        totalsAppointmentTypeColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentType"));
        totalsAppointmentTypeTotalColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentTypeTotal"));
        totalsAppointmentMonthColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentMonth"));
        totalsAppointmentMonthTotalColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentMonthTotal"));
        customerState.setCellValueFactory(new PropertyValueFactory<>("customerState"));
        customerStateTotal.setCellValueFactory(new PropertyValueFactory<>("customerStateTotal"));

        // Set contacts in contactScheduleChoice choice box
        ObservableList<Contacts> contactsObservableList = contactsAccess.getAllContacts();
        ObservableList<String> allContactsNames = FXCollections.observableArrayList();
        contactsObservableList.forEach(contacts -> allContactsNames.add(contacts.getContactName()));
        contactScheduleChoice.setItems(allContactsNames);

        totalAppointmentsTab();
        customersStateTab();

    }

    /**
     * Retrieves and displays appointments by contact based on the selected contact in the choice box.
     */
    @FXML
    public void appointmentsByContact() {
        try {

            int contactID = 0;

            ObservableList<Appointments> getAllAppointmentInfo = appointmentsAccess.getAllAppointments();
            ObservableList<Appointments> appointmentInfo = FXCollections.observableArrayList();
            ObservableList<Contacts> getAllContacts = contactsAccess.getAllContacts();

            Appointments contactAppointmentInfo;

            String contactName = (String) contactScheduleChoice.getSelectionModel().getSelectedItem();

            for (Contacts contact: getAllContacts) {
                if (contactName.equals(contact.getContactName())) {
                    contactID = contact.getContactID();
                }
            }

            for (Appointments appointment: getAllAppointmentInfo) {
                if (appointment.getContactID() == contactID) {
                    contactAppointmentInfo = appointment;
                    appointmentInfo.add(contactAppointmentInfo);
                }
            }
            allAppointmentsTable.setItems(appointmentInfo);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * Displays total appointments by month, and total appointments by type in their respective tabs.
     */
    @FXML
    public void totalAppointmentsTab() {
        try {
            ObservableList<Appointments> getAllAppointments = appointmentsAccess.getAllAppointments();

            // Create HashMap for month counts
            Map<Month, Integer> monthCounts = new HashMap<>();

            // Gather month information from appointments
            for (Appointments appointment : getAllAppointments) {
                Month month = appointment.getAppointmentStart().getMonth();
                monthCounts.put(month, monthCounts.getOrDefault(month, 0) + 1);
            }

            // Create Report objects for all months
            ObservableList<Report> monthReports = FXCollections.observableArrayList();

            for (Month month : Month.values()) {
                Report report = new Report();
                report.appointmentMonth = month.getDisplayName(TextStyle.FULL, Locale.getDefault());
                report.appointmentMonthTotal = monthCounts.getOrDefault(month, 0);
                monthReports.add(report);
            }


            // Create Report objects only for unique types using a hash map, incrementing counts
            Map<String, Report> typeReportsMap = new HashMap<>();
            for (Appointments appointment : getAllAppointments) {
                String type = appointment.getAppointmentType();
                Report report = typeReportsMap.get(type);
                if (report == null) {
                    report = new Report();
                    report.appointmentType = type;
                    typeReportsMap.put(type, report);
                }
                report.appointmentTypeTotal++;
            }

            // Convert the map to an ObservableList for the table
            ObservableList<Report> typeReports = FXCollections.observableArrayList(typeReportsMap.values());


            // Set items for the table
            appointmentTypeTotalTable.setItems(typeReports);
            appointmentMonthTotalTable.setItems(monthReports);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    /**
     * Displays customer locations and the total number of customers in each location.
     *
     * @throws SQLException If an SQL exception occurs during the retrieval of customer data.
     */
    @FXML
    public void customersStateTab() throws SQLException {
        // Retrieve all customers
        ObservableList<Customers> getAllCustomers = customersAccess.getAllCustomers();

        // Create a map to track states and counts
        Map<String, Integer> stateCounts = new HashMap<>();

        // Iterate through customers and count occurrences of each state
        for (Customers customer : getAllCustomers) {
            String state = customer.getCustomerDivision();  // Access the state (division) from the customer
            stateCounts.put(state, stateCounts.getOrDefault(state, 0) + 1);
        }

        // Create Report objects for all months
        ObservableList<Report> stateReports = FXCollections.observableArrayList();
        for (String state : stateCounts.keySet()) {
            Report report = new Report();
            report.customerState = state;
            report.customerStateTotal = stateCounts.getOrDefault(state, 0);
            stateReports.add(report);
        }
            // Set items for the table
            customerLocationTotalTable.setItems(stateReports);
        }

    /**
     * Handles the action when the "Exit" button is clicked, closing the current stage.
     *
     * @param event The ActionEvent triggered by the button click.
     */
    @FXML
    public void exitButton (ActionEvent event){
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

}
