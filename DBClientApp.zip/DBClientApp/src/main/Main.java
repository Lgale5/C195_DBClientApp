package main;

import helper.JDBC;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * The main class of the Appointment Application.
 * Extends the JavaFX Application class to start the application.
 */
public class Main extends Application {

    /**
     * Starts the application.
     * @param stage The stage to start the application on.
     * @throws IOException
     */
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("../views/loginScreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 550, 350);
        stage.setTitle("Appointment Application");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * The main method to launch the JavaFX application.
     * Opens a JDBC connection, launches the JavaFX application, and closes the JDBC connection afterward.
     *
     * @param args The command-line arguments.
     */
    public static void main(String[] args) {
        // Set the default locale to French for testing
        //Locale.setDefault(new Locale("fr"));
        JDBC.openConnection();
        launch();
        JDBC.closeConnection();
    }


}